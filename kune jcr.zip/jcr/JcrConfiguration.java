package org.ourproject.kune.platf.server.jcr;

public interface JcrConfiguration {
    String getRepositoryName();

    String getConfigFile();

    String getHomeDir();
}
